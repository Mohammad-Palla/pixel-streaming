# Frontend_Webapp


### To Do
 - reactstrap
 - react toastify
 - react spring
 - bootstrap
 - JWT Authentication or Oauth
 - react redux (X)