export default function ApplicationDetails() {
    return (
        <div id="appdetails">
            <p>
                This is the Application Details page.
            </p>
        </div>
    )
}