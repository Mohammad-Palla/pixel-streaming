export default function Billing() {
    return (
        <div id="billing">
            <h1>Billing</h1>
            <p>
                This is the billing page.
            </p>
        </div>
    )
}