export default function Profile() {
    return (
        <div id="profile">
            <h1>Profile</h1>
            <p>
                This is the profile page.
            </p>
        </div>
    )
}